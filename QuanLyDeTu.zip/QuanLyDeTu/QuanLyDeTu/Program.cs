using System;

// Phần 1: Khởi tạo và Git

/*
Tạo một dự án Console Application mới trong C# có tên QuanLyDeTu.

Mở terminal tại thư mục dự án, thực hiện các lệnh Git cơ bản:

Khởi tạo repository: git init
Thêm file: git add .
Commit lần đầu: git commit -m "Khoi tao du an QuanLyDeTu"
*/

// Phần 2: Lớp, Đối tượng và Biến

public class DeTu
{
    // Thuộc tính
    public string Ten;
    public int CanCung;
    public double[] DiemKhaoHach = new double[3];

    // Hàm nhập thông tin đệ tử
    public void NhapThongTin()
    {
        Console.Write("Nhap ten de tu: ");
        Ten = Console.ReadLine();

        Console.Write("Nhap can cot (1-10): ");
        CanCung = int.Parse(Console.ReadLine());

        Console.WriteLine("Nhap 3 diem khao hach:");
        Console.Write("  The luc: ");
        DiemKhaoHach[0] = double.Parse(Console.ReadLine());
        Console.Write("  Linh luc: ");
        DiemKhaoHach[1] = double.Parse(Console.ReadLine());
        Console.Write("  Ngo tinh: ");
        DiemKhaoHach[2] = double.Parse(Console.ReadLine());
    }

    // Hàm tính tổng 3 điểm khảo hạch
    public double TinhDiemTong()
    {
        return DiemKhaoHach[0] + DiemKhaoHach[1] + DiemKhaoHach[2];
    }

    // Hàm hiển thị thông tin
    public void HienThi()
    {
        Console.WriteLine("=== THONG TIN DE TU ===");
        Console.WriteLine("Ten de tu : " + Ten);
        Console.WriteLine("Can cot   : " + CanCung);
        Console.WriteLine("The luc   : " + DiemKhaoHach[0]);
        Console.WriteLine("Linh luc  : " + DiemKhaoHach[1]);
        Console.WriteLine("Ngo tinh  : " + DiemKhaoHach[2]);
        Console.WriteLine("Diem tong : " + TinhDiemTong());
    }
}

// Phần 3: Vòng lặp, Điều Kiện, Hàm xử lý chính
class Program
{
    static void Main(string[] args)
    {
        DeTu[] danhSach = new DeTu[100];
        int soLuong = 0;
        int luaChon;
        while (true)
        {
            Console.WriteLine("\n== MENU QUAN LY DE TU ===");
            Console.WriteLine("1. Them de tu moi");
            Console.WriteLine("2. Hien thi danh sach de tu");
            Console.WriteLine("3. Tim de tu xuat sac (Diem tong > 25)");
            Console.WriteLine("4. Ma tran Tu Linh");
            Console.WriteLine("5. Thoat chuong trinh");
            Console.Write("Nhap lua chon: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    if (soLuong >= 100)
                    {
                        Console.WriteLine("Danh sach da day!");
                    }
                    else
                    {
                        danhSach[soLuong] = new DeTu();
                        danhSach[soLuong].NhapThongTin();
                        soLuong++;
                        Console.WriteLine("Them de tu thanh cong!");
                    }
                    break;

                case 2:
                    if (soLuong == 0)
                    {
                        Console.WriteLine("Chua co de tu nao trong danh sach.");
                    }
                    else
                    {
                        Console.WriteLine("\n===== DANH SACH DE TU =====");
                        for (int i = 0; i < soLuong; i++)
                        {
                            Console.WriteLine("\nDe tu #" + (i + 1));
                            danhSach[i].HienThi();
                        }
                    }
                    break;

                case 3:
                    Console.WriteLine("\n=== DE TU XUAT SAC (Diem tong > 25) ===");
                    bool timThay = false;
                    for (int i = 0; i < soLuong; i++)
                    {
                        if (danhSach[i].TinhDiemTong() > 25)
                        {
                            danhSach[i].HienThi();
                            timThay = true;
                        }
                    }
                    if (!timThay)
                        Console.WriteLine("Khong co de tu nao dat diem tong > 25.");
                    break;

                case 4:
                    Console.WriteLine("Thoat chuong trinh. Tam biet!");
                    return;

                // Phần 4: Mảng đa chiều & Tư duy lập trình
                case 5:
                    Console.WriteLine("\n=== MA TRAN TU LINH (3x3) ===");
                    int[,] maTranLinhKhi = new int[3, 3];
                    Random rand = new Random();
                    // Gán giá trị ngẫu nhiên từ 1 đến 100
                    for (int i = 0; i < 3; i++)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            maTranLinhKhi[i, j] = rand.Next(1, 101);
                        }
                    }
                    // In ma trận dạng lưới
                    Console.WriteLine("Ma tran Linh Khi:");
                    for (int i = 0; i < 3; i++)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            Console.Write(maTranLinhKhi[i, j].ToString().PadLeft(5));
                        }
                        Console.WriteLine();
                    }
                    // Tìm vị trí có linh khí cao nhất
                    int maxVal = maTranLinhKhi[0, 0];
                    int maxHang = 0, maxCot = 0;
                    for (int i = 0; i < 3; i++)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            if (maTranLinhKhi[i, j] > maxVal)
                            {
                                maxVal = maTranLinhKhi[i, j];
                                maxHang = i;
                                maxCot = j;
                            }
                        }
                    }
                    Console.WriteLine($"Vi tri linh khi cao nhat: [{maxHang}, {maxCot}] = {maxVal}");
                    break;

                default:
                    Console.WriteLine("Lua chon khong hop le, vui long nhap lai.");
                    break;
            }
        }
    }
}
